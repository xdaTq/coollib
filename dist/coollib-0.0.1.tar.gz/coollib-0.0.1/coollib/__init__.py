def add_numbers(num1, num2):
    return num1 + num2

def sub_numbers(num1, num2):
    return num1 - num2

def multi_numbers(num1, num2):
    return num1 * num2

def div_numbers(num1, num2):
    return num1 / num2


print(add_numbers(5, 6))

